package com.example.demo.orderservice;

import org.springframework.cloud.netflix.ribbon.RibbonClient;

@org.springframework.cloud.netflix.feign.FeignClient(name="order-service")
public interface OrderItemServiceProxy {

}
