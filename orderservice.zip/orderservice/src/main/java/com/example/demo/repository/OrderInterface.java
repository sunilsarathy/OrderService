package com.example.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.orderservice.Order;

public interface OrderInterface extends JpaRepository<Order,Long> {

}
