package com.example.demo.exception;

public class OrderNotfoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
