package com.example.demo.orderservice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Data
@Entity
public class Order {
	@Id
	@GeneratedValue
	private Long id;
    private String orderDate;
    private String customerName;
    private String Address;
    private List<String> orderitems= new ArrayList<>();
    private int total;

    public Order(final String orderDate, final String customerName, final String Address,int total) {
        this.orderDate = orderDate;
        this.customerName = customerName;
        this.Address = Address;
        this.total=total;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public List<String> getOrderitems() {
		return orderitems;
	}

	public void setOrderitems(List<String> orderitems) {
		this.orderitems = orderitems;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

    
    
}
