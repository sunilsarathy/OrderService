package com.example.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.orderservice.Order;
import com.example.demo.repository.OrderInterface;

import java.util.Arrays;
import java.util.List;

@RestController
public class OrderController {
	
	@Autowired
    private OrderInterface repository;
    private final List<Order> orders = Arrays.asList(
            new Order("06/25/2020", "Ravi", "Bangalore",1),
            new Order("06/26/2020", "Ram", "Chennai",5),
            new Order("06/27/2020", "Raju", "Hyderabad",6),
            new Order("06/28/2020", "Sam", "Ahmedabad",7),
            new Order("06/29/2020", "Tom", "Pune",8));

    @GetMapping
    public List<Order> getAllOrders() {
        return orders;
    }

    @GetMapping("/{id}")
    public Order getOrderById(@PathVariable int id) {
        return orders.stream()
                     .filter(order -> order.getId() == id)
                     .findFirst()
                     .orElseThrow(IllegalArgumentException::new);
    }
    
    @PostMapping("/employees")
    Order newOrder(@RequestBody Order newEmployee) {
      return repository.save(newEmployee);
    }
}
