package com.example.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.orderservice.Order;
import com.example.demo.repository.OrderInterface;
import com.example.orderitemservice.model.OrderItem;
import com.example.repository.OrderItemRepository;

import java.util.Arrays;
import java.util.List;

@RestController
public class OrderItemController {
	
	@Autowired
    private  OrderItemRepository repository;
    private final List<OrderItem> orders = Arrays.asList(
            new OrderItem(1, "Pen", 1),
            new OrderItem(2, "Computers", 2),
            new OrderItem(3, "Mouse",3),
            new OrderItem(4, "Keyboard",7));

    @GetMapping
    public List<OrderItem> getAllOrders() {
        return orders;
    }

    @GetMapping("/{id}")
    public OrderItem getOrderById(@PathVariable int id) {
        return orders.stream()
                     .filter(order -> order.getProductCode() == id)
                     .findFirst()
                     .orElseThrow(IllegalArgumentException::new);
    }
    
    @PostMapping("/employees")
    OrderItem newOrder(@RequestBody OrderItem newEmployee) {
      return repository.save(newEmployee);
    }
}
