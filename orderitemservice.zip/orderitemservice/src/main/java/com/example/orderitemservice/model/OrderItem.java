package com.example.orderitemservice.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "ORDER_ITEM")
public class OrderItem {
	@Id
	@GeneratedValue
	private Long productCode;

	@NotNull
	private String productName;

	@NotNull
	private long itemQuantity;
	
	public OrderItem(final long productCode, final String productName, final long itemQuantity) {
        this.productCode = productCode;
        this.productName = productName;
        this.itemQuantity = itemQuantity;
    }


	public long getProductCode() {
		return productCode;
	}

	public void setProductCode(long productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public long getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(long itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

}
